package hw1;

public class Practice2 {
	public static void main(String[] args) {
		int dozens = 200 / 12;
		int remainingEggs = 200 % 12;

		System.out.println("200顆雞蛋共是" + dozens + "打" + remainingEggs + "顆");

//		試著寫方法二
//		System.out.printf("200顆雞蛋共是%d打%d顆", 200 / 12, 200 % 12);
	}

}
