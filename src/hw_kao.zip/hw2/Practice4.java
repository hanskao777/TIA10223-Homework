package hw2;

public class Practice4 {
	public static void main(String[] args) {
		int i = 1;
		while (i * i <= 100) {
			System.out.print(i * i + " ");
			i++;
		}
	}
}
